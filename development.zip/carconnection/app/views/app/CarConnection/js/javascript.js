function init () {
    alert ('loaded');
}
    