/*  Google has a cool visualization called geocharts:
https://developers.google.com/chart/interactive/docs/gallery/geochart

JSFiddle Examples:
http://jsfiddle.net/api/post/library/pure/

Longitutde and Latitude samples here:
http://stackoverflow.com/questions/11863940/google-geocharts-with-coodinates

Research also, http://polymaps.org/

*/