{
  "authors": [
    {
      "name": "Author One"
      "color": "Blue"
      "description": "This is a description of Author One."
    },
    {
      "name": "Author Two"
      "color": "Red"
      "description": "This is a description of Author Two."
    },
    {
      "name": "Author Three"
      "color": "Green"
      "description": "This is a description of Author Three."
    },
    {
      "name": "Author Four"
      "color": "Orange"
      "description": "This is a description of Author Four."
    }
  ]
}
